## Сниппет
````
    ExecuteProcess('}b.security.evaluate.mdx.private',
       'pLogOutput', pLogOutput,
       'pStrictErrorHandling', pStrictErrorHandling,
       'pUser', pUser,
       'pDimension', pDimension,
       'pSubset', pSubset,
       'pSubsetFile', pSubsetFile,
       'pFilePath', pFilePath,
       'pFileName', pFileName,
       'pDelim', pDelim,
       'pQuote', pQuote
      );
````