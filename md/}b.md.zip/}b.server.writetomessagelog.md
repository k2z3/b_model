## Описание
   
  Этот процесс запишет сообщение в журнал сообщений сервера TM1.
## Параметры процесса
  
|Параметр|Тип данных|По умолчанию|Текст подсказки|
   |---|:-:|:-:|---|
   |`pLogOutput`|N|`0`|НЕОБЯЗАТЕЛЬНО: записывать параметры и сводку действий в журнал сообщений сервера (логическое значение True = 1)|
   |`pLevel`|S||ОБЯЗАТЕЛЬНО: серьезность сообщения – INFO, DEBUG или ERROR|
   |`pMessage`|S||ОБЯЗАТЕЛЬНО: сообщение для отображения в журнале сообщений сервера TM1|
   ## Полные зависимости процесса
Процесс не имеет никаких зависимостей.

## Сниппет
```
    ExecuteProcess( '}b.server.writetomessagelog', 'pLogOutput', pLogOutput,
      'pStrictErrorHandling', pStrictErrorHandling,
    	'pLevel', '', 'pMessage', ''
    );
```

## Пример вызова
```
    ExecuteProcess( '}b.server.writetomessagelog', 
    	'pLevel', 'ERROR', 'pMessage', 'test message'
    );
```

## Замечания
* По сути тот же LogOutput...

![scr](scr/}b.server.writetomessagelog.PNG)