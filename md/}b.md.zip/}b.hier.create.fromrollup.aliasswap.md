## Описание
   
 Этот процесс создаст альтернативную иерархию из консолидированного элемента и его дочерних элементов в иерархии по умолчанию.
     
**Вариант использования:** предназначен для разработки, но может использоваться и в рабочей среде.
1. Создайте новую иерархию для тестирования.
2. Создайте новую иерархию, чтобы отразить новые потребности бизнеса.
     
**Примечание:**
 Допустимое имя исходного измерения (`pSrcDim`) и исходное подмножество (pSubset) являются обязательными, иначе процесс будет прерван.
 Если указано имя исходной иерархии (`pSrcHier`), оно должно быть допустимым, иначе процесс будет прерван.
     
**Внимание:**
 - Целевая иерархия не может быть «конечной».
 - Если целевая иерархия уже существует, она будет перезаписана.
## Параметры процесса
  
|Параметр|Тип данных|По умолчанию|Текст подсказки|
  |---|:-:|:-:|---|
  |`pLogOutput`|N|`0`|НЕОБЯЗАТЕЛЬНО: записывать параметры и сводку действий в журнал сообщений сервера (логическое значение True = 1)|
  |`pSrcDim`|S||ОБЯЗАТЕЛЬНО: исходное измерение|
  |`pSrcHier`|S||НЕОБЯЗАТЕЛЬНО: Исходная иерархия (пробел = то же имя, что и исходное измерение)|
  |`pConsol`|S||ОБЯЗАТЕЛЬНО: элемент Cons в исходном dim для создания корневого элемента в target|
  |`pTgtDim`|S||НЕОБЯЗАТЕЛЬНО: Целевое измерение (пусто = то же имя, что и исходное измерение)|
  |`pTgtHier`|S||НЕОБЯЗАТЕЛЬНО: целевая иерархия (пусто = то же имя, что и целевое измерение)|
  |`pAttr`|N|`1`|НЕОБЯЗАТЕЛЬНО: Включить атрибуты? (логическое значение 1=Истина)|
  |`pUnwind`|N|`2`|НЕОБЯЗАТЕЛЬНО: 0 = удалить все элементы, 1 = удалить существующие элементы, 2 = не изменять существующие элементы|
  |`pRemove`|N|`0`|НЕОБЯЗАТЕЛЬНО: удалить элементы cons из исходного кода? (1 = Да, 0 = Нет)|
  |`pAliasSwap`|S||ОБЯЗАТЕЛЬНО: Имя атрибута с именами, которые нужно поменять местами|
  ## Полные зависимости процесса
  
|Процесс|ExecuteProcess|RunProcess|
  |---|:-:|:-:|
  |[`}b.hier.sub.create`](}b.hier.sub.create)|Y|N|
  |[`}b.hier.create.fromsubset`](}b.hier.create.fromsubset)|Y|N|
  |[`}b.dim.attr.create`](}b.dim.attr.create)|Y|N|
  |[`}b.cube.data.copy`](}b.cube.data.copy)|Y|N|
  |[`}b.dim.attr.swapalias`](}b.dim.attr.swapalias)|Y|N|
  |[`}b.dim.attr.delete`](}b.dim.attr.delete)|Y|N|
  |[`}b.dim.delete`](}b.dim.delete)|Y|N|
  |[`}b.hier.unwind`](}b.hier.unwind)|Y|N|
  |[`}b.hier.emptyconsols.delete`](}b.hier.emptyconsols.delete)|Y|N|
  |[`}b.hier.sub.exclude`](}b.hier.sub.exclude)|Y|N|
  |[`}b.cube.data.clear`](}b.cube.data.clear)|Y|N|
  |[`}b.cube.view.create`](}b.cube.view.create)|Y|N|
  |[`}b.cube.data.export`](}b.cube.data.export)|Y|N|
  |[`}b.hier.sub.create.bymdx`](}b.hier.sub.create.bymdx)|Y|N|

## Сниппет
```
    ExecuteProcess( '}b.hier.create.fromrollup.aliasswap', 'pLogOutput', pLogOutput,
      'pStrictErrorHandling', pStrictErrorHandling,
    	'pSrcDim', '', 'pSrcHier', '', 'pConsol', '',
    	'pTgtDim', '', 'pTgtHier', '',
    	'pAttr', 1, 'pUnwind', 2, 'pRemove', 0,
    	'pAliasSwap', ''
	);
```