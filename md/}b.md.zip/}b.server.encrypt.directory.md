## Сниппет
```
    ExecuteProcess('}b.server.encrypt.directory',
       'pLogOutput', pLogOutput,
       'pStrictErrorHandling', pStrictErrorHandling,
       'pType', pType,
       'pDirectory', pDirectory,
       'pDestPath', pDestPath,
       'pConfigLocation', pConfigLocation,
       'pTM1CryptLocation', pTM1CryptLocation,
       'pAction', pAction
    );

```