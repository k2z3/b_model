## Сниппет
```
    ExecuteProcess('}b.server.encrypt.file', 'pLogOutput', pLogOutput,
       'pStrictErrorHandling', pStrictErrorHandling,
       'pSourcePath', pSourcePath,
       'pSourceFile', pSourceFile,
       'pDestPath', pDestPath,
       'pConfigLocation', pConfigLocation,
       'pTM1CryptLocation', pTM1CryptLocation,
       'pAction', pAction
    );
```