## Описание
   
 Этот TI удаляет измерение из уже построенного куба с возможностью сохранения данных.
     
**Вариант использования:** предназначен для разработки/прототипирования.
1. Перестроить существующий куб с удалением одного измерения без потери всех данных.
     
**Примечание:**
 Естественно, действительное имя куба (`pCube`) обязательно, иначе процесс прервется.
 Кроме того, допустимое имя измерения (`pDim`) является обязательным, иначе процесс будет прерван.
 Если данные необходимо сохранить (используя `pIncludeData`), данные из `pDim` будут суммироваться.
 Правило можно сохранить только как резервный файл или перезагрузить обратно.
## Параметры процесса
  
|Параметр|Тип данных|По умолчанию|Текст подсказки|
  |---|:-:|:-:|---|
  |`pLogOutput`|N|`0`|НЕОБЯЗАТЕЛЬНО: Необязательно: записывать параметры и сводку действий в журнал сообщений сервера (логическое значение True = 1)|
  |`pCube`|S||ОБЯЗАТЕЛЬНО: Куб|
  |`pDim`|S||ОБЯЗАТЕЛЬНО: удаляемое измерение|
  |`pIncludeData`|N|`1`|ОБЯЗАТЕЛЬНО: Если 1, то данные сохраняются (копируются через клонированный куб)|
  |`pIncludeRules`|N|`2`|ОБЯЗАТЕЛЬНО: выгрузить и перезагрузить правило (0 = не сохранять правило, 1 = выгрузить правило, 2 = выгрузить правило и перезагрузить в новый куб)|
  |`pCtrlObj`|N|`0`|ОБЯЗАТЕЛЬНО: Разрешить перезапись управляющих кубов|
  |`pTemp`|N|`1`|ОБЯЗАТЕЛЬНО: удалить куб-клон (1 = удалить, 0 = не удалять)|
  ## Полные зависимости процесса
  
|Процесс|ExecuteProcess|RunProcess|
  |---|:-:|:-:|
  |[`}b.cube.rule.manage`](}b.cube.rule.manage)|Y|N|
  |[`}b.cube.clone`](}b.cube.clone)|Y|N|
  |[`}b.cube.create`](}b.cube.create)|Y|N|
  |[`}b.cube.data.copy.intercube`](}b.cube.data.copy.intercube)|Y|N|
  |[`}b.cube.delete`](}b.cube.delete)|Y|N|
  |[`}b.hier.sub.create.bymdx`](}b.hier.sub.create.bymdx)|Y|N|
  |[`}b.cube.view.create`](}b.cube.view.create)|Y|N|
  |[`}b.cube.data.clear`](}b.cube.data.clear)|Y|N|
  |[`}b.cube.data.export`](}b.cube.data.export)|Y|N|
  |[`}b.hier.sub.create`](}b.hier.sub.create)|Y|N|
  |[`}b.hier.sub.exclude`](}b.hier.sub.exclude)|Y|N|
  

## Сниппет
```
    ExecuteProcess( '}b.cube.dimension.delete', 'pLogOutput', pLogOutput,
      'pStrictErrorHandling', pStrictErrorHandling,
    	'pCube', '', 'pDim', '',
    	'pIncludeData', 1, 'pIncludeRules', 2,
    	'pCtrlObj', 0, 'pTemp', 1
	);
```

## Пример
* Удалить ненужное измерение из куба (с сохранением данных и правил)
```
    ExecuteProcess( '}b.cube.dimension.delete', 
    	'pCube', 'Cube1', 'pDim', 'Version',
    	'pIncludeData', 1, 'pIncludeRules', 2,
    	'pCtrlObj', 1, 'pTemp', 1
	);
```