## Сниппет
````
    ExecuteProcess('}b.security.evaluate.mdx', 'pLogOutput', pLogOutput,
       'pStrictErrorHandling', pStrictErrorHandling,
       'pNameSpace', 0,
       'pFilePath', pFilePath,
       'pFileName', pFileName,
       'pDelim', pDelim,
       'pQuote', pQuote
    );
````